// Este módulo ha sido deshabilitado ya que la exportación a HTML ya no es necesaria.
// Se ha decidido exportar directamente desde la Vista Previa a PDF.

// Código eliminado intencionalmente siguiendo la nueva estrategia del proyecto.

const exportadorHTML = () => {
  console.warn("La exportación a HTML ha sido deshabilitada. Usa la vista previa para exportar a PDF.");
};

export default exportadorHTML;
